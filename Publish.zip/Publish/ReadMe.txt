Run the Terminal as Adminstrator
Create the Service
sc.exe create "Executor Service" binpath="D:\DotNet\Publish\BatchWorker.exe"
<<OR>>
sc.exe create "Executor Service" binpath="D:\DotNet\Publish\BatchWorker.exe --contentRoot D:\DotNet\Contents"
Optional Failure conigurations
sc.exe failure "Executor Service" reset=0 actions=restart/60000/restart/60000/run/1000
sc.exe qfailure "Executor Service"
To Start the service
sc.exe start "Executor Service"
To Stop the Service
sc.exe stop "Executor Service"
To Delete the service
sc.exe delete "Executor Service"
